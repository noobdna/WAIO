#!/bin/bash
REQUEST="$1"
echo "[RESEARCH WORKER] received: $REQUEST"
echo "[RESEARCH WORKER] research task completed"
