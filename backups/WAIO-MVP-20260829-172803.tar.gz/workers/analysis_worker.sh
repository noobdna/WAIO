#!/bin/bash
REQUEST="$1"
echo "[ANALYSIS WORKER] received: $REQUEST"
echo "[ANALYSIS WORKER] analysis task completed"
